public interface IScan {
    public String scan();
}
