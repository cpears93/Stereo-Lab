public class ThemePark {
}
