package behaviours;

public interface ISecurity {
}
