package behaviours;

public interface IReviewed {
}
