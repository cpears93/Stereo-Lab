package behaviours;

public interface ITicketed {
}
