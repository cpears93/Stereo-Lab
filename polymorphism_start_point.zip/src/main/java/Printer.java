public class Printer {

    public String print(String data){
        return "printing: " + data;
    }
}