public class Triathlete extends Athlete {

}
