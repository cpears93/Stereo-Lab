public class Swimmer extends Athlete  {

}
